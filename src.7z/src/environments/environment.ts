// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
    firebaseConfig: {
      apiKey: "AIzaSyAG-C3FJVOH9dHpV0bAz7aXgDBfReV1wYA",
      authDomain: "alledatabase.firebaseapp.com",
      databaseURL: "https://alledatabase-default-rtdb.firebaseio.com",
      projectId: "alledatabase",
      storageBucket: "alledatabase.appspot.com",
      messagingSenderId: "459061290042",
      appId: "1:459061290042:web:fdca147045124846dcc103",
      measurementId: "G-J2S67Q6XJY"
    }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
