export class Type {
    idType: number;
    typ_name: string;
    typ_icon: string;
    size: number;
}