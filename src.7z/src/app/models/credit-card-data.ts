export class CreditCardData { 
    id: number;
    name: string;
    number: string;
    cardType: number;
    expiration: Date;
    securityNumber: string;
    cardPassword: string;
}