export class AppData { 
    id: number;
    name: string;
    user: string;
    password: string;
    activationCode: string;
    version: string;
}