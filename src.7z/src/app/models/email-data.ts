export class EmailData {
    id: number;
    name: string;
    email: string;
    password: string;
}