export class WebData { 
    id: number;
    url: string;
    name: string;
    user: string;
    password: string;
}