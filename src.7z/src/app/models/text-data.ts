export class TextData { 
    id: number;
    name: string;
    text: string;
}