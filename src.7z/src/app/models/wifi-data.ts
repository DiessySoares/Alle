export class WifiData { 
    id: number;
    name: string;
    user: string;
    password: string;
    connectionType: string;
    authenticationMethod: string;
}